// Owns every network call and the launchWebAuthFlow window. Runs here (not in
// the popup) because the popup's JS context is destroyed on close, which would
// orphan a pending launchWebAuthFlow promise.
import { BUILD_CP_BASE_URL } from '../build-config.js';
import { Auth } from '../lib/auth.js';
import { parseAuthRedirect } from '../lib/parse-auth-redirect.js';
import { getInstanceBaseUrl } from '../lib/instance-url.js';
import { toWebSocketUrl } from '../lib/ws-url.js';
import { createClient } from '../lib/ws-client.js';
import { formatMachine, formatBrowser } from '../lib/describe-device.js';
import { emptyLedger } from '../lib/command-ledger.js';
import { createActivityIndicator } from '../lib/activity-indicator.js';
import { createExecutor, createLoadWaiter } from '../lib/browser-commands.js';

const EMAIL_LOGIN_DISABLED_TEXT =
  "Email login isn't enabled for this account. Use Google or Apple.";
const INVALID_CREDENTIALS_TEXT = 'Invalid email or password.';

// MV3 clamps periodInMinutes to a 1 minute floor for a packed extension, so
// anything smaller silently becomes 1 anyway. This alarm is the only thing
// that can revive a terminated service worker -- setTimeout does not survive
// termination -- so it stands in for the backoff timer whenever the worker
// has been killed mid-wait, and after chrome.runtime.reload() (which clears
// alarms) it has to be recreated, which is why ensureAlarm runs on every
// worker start.
const ALARM_NAME = 'pana-keepalive';
const ALARM_PERIOD_MINUTES = 1;
const LEDGER_KEY = 'command_ledger';
const CONNECTION_STATE_KEY = 'connection_state';
const DEVICE_ID_KEY = 'device_id';
// chrome.storage.session (not .local): a window id is meaningless after a
// browser restart, and session is TRUSTED_CONTEXTS-only by default.
const PANA_WINDOW_TARGET_KEY = 'pana_window_target';

async function getSocketUrl() {
  const { instance } = await Auth.getStored();
  if (!instance) return null;
  return toWebSocketUrl(getInstanceBaseUrl(instance));
}

async function getToken({ forceRefresh } = {}) {
  const { access, refresh } = await Auth.getStored();
  if (!refresh) return null;
  if (forceRefresh || Auth.isTokenExpired(access)) {
    const refreshed = await Auth.refreshToken();
    if (!refreshed.ok) return null;
    return (await Auth.getStored()).access;
  }
  return access;
}

// `upload` (browser-commands.js): fetch a server-staged, one-time file URL
// with the extension's own JWT. Only ever a path on the paired instance.
async function fetchUpload(path) {
  if (typeof path !== 'string' || !path.startsWith('/api/extension/upload/')) {
    throw new Error('not an upload URL');
  }
  const { instance } = await Auth.getStored();
  const token = await getToken();
  if (!instance || !token) throw new Error('not signed in');
  const res = await fetch(`${getInstanceBaseUrl(instance)}${path}`, {
    headers: { Authorization: `Bearer ${token}` },
    cache: 'no-store',
  });
  if (!res.ok) throw new Error(`staged file fetch failed: ${res.status}`);
  return new Uint8Array(await res.arrayBuffer());
}

async function getIdentity() {
  const stored = await chrome.storage.local.get([DEVICE_ID_KEY]);
  let deviceId = stored[DEVICE_ID_KEY];
  if (!deviceId) {
    deviceId = crypto.randomUUID();
    await chrome.storage.local.set({ [DEVICE_ID_KEY]: deviceId });
  }
  const platformInfo = await chrome.runtime.getPlatformInfo();
  return {
    device_id: deviceId,
    machine: formatMachine(platformInfo),
    browser: formatBrowser(navigator.userAgent),
    version: chrome.runtime.getManifest().version,
  };
}

async function loadLedger() {
  const stored = await chrome.storage.local.get([LEDGER_KEY]);
  return stored[LEDGER_KEY] || emptyLedger();
}

async function saveLedger(ledger) {
  await chrome.storage.local.set({ [LEDGER_KEY]: ledger });
}

async function onState(state) {
  await chrome.storage.local.set({ [CONNECTION_STATE_KEY]: state });
}

const loadTarget = {
  async get() {
    const stored = await chrome.storage.session.get([PANA_WINDOW_TARGET_KEY]);
    return stored[PANA_WINDOW_TARGET_KEY] || null;
  },
  async set(target) {
    await chrome.storage.session.set({ [PANA_WINDOW_TARGET_KEY]: target });
  },
  async clear() {
    await chrome.storage.session.remove([PANA_WINDOW_TARGET_KEY]);
  },
};

// The sawLoading-gated wait logic lives in the pure loadWaiter (testable
// without chrome.*); onUpdated/onRemoved below are thin top-level wrappers,
// since chrome.tabs.onUpdated has no filter argument to narrow with.
const loadWaiter = createLoadWaiter({ setTimeoutImpl: setTimeout, clearTimeoutImpl: clearTimeout });

const indicator = createActivityIndicator({
  tabs: chrome.tabs,
  tabGroups: chrome.tabGroups,
  action: chrome.action,
  scripting: chrome.scripting,
  loadTarget,
});

const executor = createExecutor({
  windows: chrome.windows,
  tabs: chrome.tabs,
  scripting: chrome.scripting,
  downloads: chrome.downloads,
  fetchUpload,
  loadTarget,
  // Groups the tab the moment it exists, so the "Pana" label is already on
  // it while the first page loads. Not awaited: navigate must never wait on
  // decoration.
  onTarget: (target) => {
    indicator.markTab(target);
  },
  waitForLoad: (tabId, timeoutMs) => loadWaiter.waitForLoad(tabId, timeoutMs),
  sleep: (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
});

// unsupported_verb is the executor's own default for anything outside the
// verbs it implements (see VERBS in browser-commands.js, incl. tabs.*).
async function execute(verb, params) {
  return indicator.track(verb, () => executor.execute(verb, params));
}

// Registered synchronously at the top level -- see chrome.runtime.onStartup
// below for why. chrome.tabs.onUpdated has no per-tab filter, so every
// change funnels through the pending-tab Map in loadWaiter.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  loadWaiter.onUpdated(tabId, changeInfo);
  indicator.onTabUpdated(tabId, changeInfo);
});

// The boss closing Pana's window by hand: reject any pending waiter for it
// and self-heal storage so the next navigate() recreates the window instead
// of retrying against a dead id forever.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  loadWaiter.onRemoved(tabId);
  const target = await loadTarget.get();
  if (!target || target.tabId !== tabId) return;
  // Pana's current tab closed by hand: fall back to another tab in Pana's
  // own window if one is left, else forget the window entirely.
  let remaining = [];
  try {
    remaining = await chrome.tabs.query({ windowId: target.windowId });
  } catch {
    remaining = [];
  }
  const next = remaining.find((t) => t.active) || remaining[remaining.length - 1];
  if (next) await loadTarget.set({ windowId: target.windowId, tabId: next.id });
  else await loadTarget.clear();
});
chrome.windows.onRemoved.addListener(async (windowId) => {
  const target = await loadTarget.get();
  if (target && target.windowId === windowId) {
    loadWaiter.onRemoved(target.tabId);
    await loadTarget.clear();
  }
});

const client = createClient({
  getSocketUrl,
  getToken,
  getIdentity,
  loadLedger,
  saveLedger,
  execute,
  onState,
  WebSocketImpl: WebSocket,
  setTimeoutImpl: setTimeout,
  clearTimeoutImpl: clearTimeout,
});

async function ensureAlarm() {
  const existing = await chrome.alarms.get(ALARM_NAME);
  if (!existing || existing.periodInMinutes !== ALARM_PERIOD_MINUTES) {
    chrome.alarms.create(ALARM_NAME, { periodInMinutes: ALARM_PERIOD_MINUTES });
  }
}

async function signInSocial(provider) {
  const providerQuery = provider === 'apple' ? '&provider=apple' : '';
  const url = `${BUILD_CP_BASE_URL}/api/v1/auth/social/begin/?client=extension${providerQuery}`;
  let redirect;
  try {
    redirect = await chrome.identity.launchWebAuthFlow({ url, interactive: true });
  } catch (err) {
    return { ok: false, reason: 'flow_failed', message: err && err.message };
  }
  const parsed = parseAuthRedirect(redirect);
  if (!parsed) return { ok: false, reason: 'no_tokens' };
  if (parsed.waitlist) return { ok: false, reason: 'waitlist' };
  if (!parsed.access || !parsed.refresh) return { ok: false, reason: 'no_tokens' };

  await Auth.setTokens(parsed);
  client.ensureConnected();
  return { ok: true, instance: parsed.instance };
}

async function signInEmail(email, password) {
  let res;
  try {
    res = await fetch(`${BUILD_CP_BASE_URL}/api/v1/auth/email/login/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
  } catch {
    return { ok: false, reason: 'network' };
  }

  if (res.status === 401) return { ok: false, reason: 'invalid_credentials', message: INVALID_CREDENTIALS_TEXT };
  if (res.status === 404) return { ok: false, reason: 'email_login_disabled', message: EMAIL_LOGIN_DISABLED_TEXT };
  if (!res.ok) return { ok: false, reason: 'network' };

  const data = await res.json();
  // A waitlisted 200 carries access: null — storing it with setItem would
  // stringify to "null", which reads back as a live session on the next
  // getState call. Only write real tokens.
  if (data.waitlist) return { ok: false, reason: 'waitlist' };
  if (!data.access || !data.refresh) return { ok: false, reason: 'no_tokens' };

  await Auth.setTokens({ access: data.access, refresh: data.refresh, instance: data.instance });
  client.ensureConnected();
  return { ok: true, instance: data.instance };
}

async function getState() {
  const { access, refresh, instance } = await Auth.getStored();
  client.ensureConnected();
  return { signedIn: !!(access && refresh), instance };
}

// PAN-738: the popup's signed-in block reads the same whitelist the trick GUI
// writes. A fetch from a service worker isn't CORS-bound the way a content
// script is (Chrome's network-requests guide), and manifest.template.json's
// host_permissions already covers the instance host, so no new permission
// or CP-side origin change is needed for any of the calls below.
const BROWSER_EXTENSION_TRICK_ID = 'com.pana.browser-extension';

async function getPolicy() {
  const { instance } = await Auth.getStored();
  if (!instance) return { ok: false, reason: 'network' };
  const base = getInstanceBaseUrl(instance);
  let res;
  try {
    res = await Auth.authFetch(`${base}/tricks/${BROWSER_EXTENSION_TRICK_ID}/_api/queries/get_policy`);
  } catch {
    return { ok: false, reason: 'network' };
  }
  if (res.status === 404) return { ok: false, reason: 'not_installed' };
  if (!res.ok) return { ok: false, reason: 'network' };
  try {
    return { ok: true, policy: await res.json() };
  } catch {
    return { ok: false, reason: 'network' };
  }
}

async function postTrickEvent(event, payload) {
  const { instance } = await Auth.getStored();
  if (!instance) return { ok: false, reason: 'network' };
  const base = getInstanceBaseUrl(instance);
  let res;
  try {
    res = await Auth.authFetch(`${base}/tricks/${BROWSER_EXTENSION_TRICK_ID}/_api/events/${event}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
  } catch {
    return { ok: false, reason: 'network' };
  }
  if (!res.ok) return { ok: false, reason: 'network' };
  let data;
  try {
    data = await res.json();
  } catch {
    return { ok: false, reason: 'network' };
  }
  if (data && data.ok === false) return { ok: false, reason: data.error || 'network' };
  return { ok: true };
}

function cutAccess() {
  return postTrickEvent('access_set', { enabled: false });
}

// `verbs` is the site's complete verb set: site_saved replaces it.
function saveSite(site, verbs) {
  return postTrickEvent('site_saved', { site, verbs: verbs.join(',') });
}

// Same tab-with-a-query-token shape the PWA uses for its own trick launches
// (frontend/www/scripts/canvas.js:925). The tradeoff is unchanged from there:
// a short-lived access token lands in tab history, and a standalone trick
// page cannot refresh it (the SDK's refresh talks to a parent frame that
// isn't there), so a long-open tab eventually 401s and needs reopening.
async function openTrick() {
  const { instance } = await Auth.getStored();
  if (!instance) return { ok: false, reason: 'network' };
  const token = await getToken();
  if (!token) return { ok: false, reason: 'network' };
  const base = getInstanceBaseUrl(instance);
  await chrome.tabs.create({ url: `${base}/tricks/${BROWSER_EXTENSION_TRICK_ID}/?token=${token}` });
  return { ok: true };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    switch (message && message.type) {
      case 'getState':
        sendResponse(await getState());
        break;
      case 'signInSocial':
        sendResponse(await signInSocial(message.provider));
        break;
      case 'signInEmail':
        sendResponse(await signInEmail(message.email, message.password));
        break;
      case 'getConnectionState':
        sendResponse(client.getState());
        break;
      case 'getPolicy':
        sendResponse(await getPolicy());
        break;
      case 'cutAccess':
        sendResponse(await cutAccess());
        break;
      case 'saveSite':
        sendResponse(await saveSite(message.site, message.verbs));
        break;
      case 'openTrick':
        sendResponse(await openTrick());
        break;
      default:
        sendResponse({ ok: false, reason: 'unknown_message' });
    }
  })();
  return true;
});

// Registered synchronously at the top level: the worker re-runs this file on
// every wake, and a listener attached inside a promise would be missed.
chrome.runtime.onStartup.addListener(() => {
  ensureAlarm();
  client.ensureConnected();
});
chrome.runtime.onInstalled.addListener(() => {
  ensureAlarm();
  client.ensureConnected();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== ALARM_NAME) return;
  // The alarm can outlive the worker that created it; re-arm it here too so a
  // one-shot leftover (or a reload that cleared it) can't leave the backstop
  // without a next firing.
  ensureAlarm();
  client.ensureConnected();
});

ensureAlarm();
client.ensureConnected();
