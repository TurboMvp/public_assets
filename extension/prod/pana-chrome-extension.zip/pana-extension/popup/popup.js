// External module (MV3 forbids inline scripts). Mirrors the wiring in
// onboarding.html:1079-1081 and :1116-1171, but the popup never touches
// tokens directly — every call goes through the service worker.
import { getInstanceBaseUrl } from '../lib/instance-url.js';
import { formatSites, chipLabel, isChipConnected, siteFromUrl, navigateAccess } from '../lib/policy-view.js';

const statusChip = document.getElementById('status-chip');
const statusLine = document.getElementById('status-line');
const emailDialog = document.getElementById('email-dialog');
const emailForm = document.getElementById('email-form');
const emailError = document.getElementById('email-error');
const signedInBlock = document.getElementById('signed-in-block');
const instanceHostEl = document.getElementById('instance-host');
const sitesListEl = document.getElementById('sites-list');
const manageLinkEl = document.getElementById('manage-link');
const cutAccessBtn = document.getElementById('cut-access-btn');
const signedInStatus = document.getElementById('signed-in-status');
const thisTabEl = document.getElementById('this-tab');
const thisTabSiteEl = document.getElementById('this-tab-site');
const thisTabNoteEl = document.getElementById('this-tab-note');
const allowTabBtn = document.getElementById('allow-tab-btn');

// The site of the tab the popup was opened over, or null when that page
// can't be whitelisted. Resolved once per popup open.
let tabSite = null;
let lastPolicy = null;

function sendMessage(message) {
  return chrome.runtime.sendMessage(message);
}

function showStatusLine(text) {
  statusLine.textContent = text;
  statusLine.hidden = false;
}

function esc(str) {
  return String(str || '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function showSignedInStatus(text) {
  signedInStatus.textContent = text;
  signedInStatus.hidden = false;
}

// The chip used to print CONNECTED the moment the user signed in, which is
// false whenever the socket is down -- getConnectionState is the SW's actual
// WS client state, already exposed and unused by the popup until now, so the
// chip means the socket, as it does in both mockups (01-signin, 02-connected).
async function refreshChip() {
  const state = await sendMessage({ type: 'getConnectionState' });
  const connected = isChipConnected(state);
  statusChip.classList.toggle('paco-tone-success', connected);
  statusChip.textContent = chipLabel(state);
}

async function loadPolicy() {
  const result = await sendMessage({ type: 'getPolicy' });
  if (!result.ok) {
    sitesListEl.className = '';
    sitesListEl.innerHTML = '';
    manageLinkEl.hidden = true;
    showSignedInStatus(
      result.reason === 'not_installed'
        ? "Browser access isn't set up yet — install it in the Pana app."
        : 'Could not load your site whitelist right now.'
    );
    return;
  }
  manageLinkEl.hidden = false;
  lastPolicy = result.policy;
  renderThisTab();
  const rows = formatSites(result.policy);
  sitesListEl.className = 'paco-group';
  sitesListEl.innerHTML = rows.length === 0
    ? '<div class="paco-row sites-empty">No sites yet. Add one in the app.</div>'
    : rows.map((row) => `
        <div class="paco-row site-row">
          <div class="paco-cell-copy">
            <div class="paco-cell-title">${esc(row.site)}</div>
            <div class="site-verbs">${esc(row.label)}</div>
          </div>
        </div>`).join('');
}

async function resolveTabSite() {
  // The last focused normal window is the one the popup was opened over, in
  // Chrome (popup anchored to it) and in Arc (popup detached into its own
  // window, which is not "normal" and so never matches).
  const win = await chrome.windows.getLastFocused({ populate: true, windowTypes: ['normal'] });
  const tab = win && win.tabs && win.tabs.find((t) => t.active);
  return tab && tab.url ? siteFromUrl(tab.url) : null;
}

function renderThisTab() {
  if (!tabSite || !lastPolicy) {
    thisTabEl.hidden = true;
    return;
  }
  const access = navigateAccess(lastPolicy, tabSite);
  thisTabEl.hidden = false;
  thisTabSiteEl.textContent = tabSite;
  if (access.allowed) {
    thisTabNoteEl.textContent = 'Pana can open this site.';
    allowTabBtn.hidden = true;
  } else {
    thisTabNoteEl.textContent = access.listed
      ? "On your list, but Pana can't open it."
      : "Pana can't open this site yet.";
    allowTabBtn.hidden = false;
  }
}

allowTabBtn?.addEventListener('click', async () => {
  if (!tabSite || !lastPolicy) return;
  const { verbs } = navigateAccess(lastPolicy, tabSite);
  allowTabBtn.disabled = true;
  const result = await sendMessage({ type: 'saveSite', site: tabSite, verbs });
  allowTabBtn.disabled = false;
  if (!result.ok) {
    showSignedInStatus(`Could not allow ${tabSite}. Try again.`);
    return;
  }
  await loadPolicy();
});

async function showSignedIn(instance) {
  document.querySelectorAll('.signed-out-only').forEach((el) => { el.hidden = true; });
  signedInBlock.hidden = false;
  let host = instance;
  try {
    host = new URL(getInstanceBaseUrl(instance)).host;
  } catch {
    // Falls back to the raw instance id — still informative, and this is a
    // build misconfiguration rather than something the user can act on.
  }
  instanceHostEl.textContent = host;
  refreshChip();
  tabSite = await resolveTabSite().catch(() => null);
  loadPolicy();
}

manageLinkEl?.addEventListener('click', (event) => {
  event.preventDefault();
  sendMessage({ type: 'openTrick' });
});

cutAccessBtn?.addEventListener('click', async () => {
  cutAccessBtn.disabled = true;
  const result = await sendMessage({ type: 'cutAccess' });
  cutAccessBtn.disabled = false;
  if (result.ok) {
    showSignedInStatus("Access cut. Nothing can run until you restore it in the app.");
    await loadPolicy();
  } else {
    showSignedInStatus('Could not cut access. Try again.');
  }
});

const SOCIAL_FAILURE_TEXT = {
  waitlist: "You're on the waitlist. We'll let you know when your Pana is ready.",
  no_tokens: 'Sign in failed. Please try again.',
  flow_failed: 'Sign in was cancelled or failed. Please try again.',
};

async function handleSocialResult(result) {
  if (result.ok) {
    showSignedIn(result.instance);
    return;
  }
  showStatusLine(SOCIAL_FAILURE_TEXT[result.reason] || 'Sign in failed. Please try again.');
}

document.querySelector('.google-btn')?.addEventListener('click', async () => {
  const result = await sendMessage({ type: 'signInSocial', provider: 'google' });
  await handleSocialResult(result);
});

document.querySelector('.apple-btn')?.addEventListener('click', async () => {
  const result = await sendMessage({ type: 'signInSocial', provider: 'apple' });
  await handleSocialResult(result);
});

document.querySelector('.email-btn')?.addEventListener('click', () => {
  emailDialog.showModal();
});

document.getElementById('email-cancel-btn')?.addEventListener('click', () => {
  emailDialog.close();
});

const EMAIL_FAILURE_TEXT = {
  invalid_credentials: 'Invalid email or password.',
  email_login_disabled: "Email login isn't enabled for this account. Use Google or Apple.",
  network: 'Something went wrong. Please try again.',
  no_tokens: 'Something went wrong. Please try again.',
};

emailForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  emailError.hidden = true;
  const formData = new FormData(emailForm);
  const email = (formData.get('email') || '').trim();
  const password = formData.get('password');

  const result = await sendMessage({ type: 'signInEmail', email, password });

  if (result.waitlist || result.reason === 'waitlist') {
    emailDialog.close();
    showStatusLine(SOCIAL_FAILURE_TEXT.waitlist);
    return;
  }
  if (!result.ok) {
    emailError.textContent = EMAIL_FAILURE_TEXT[result.reason] || 'Something went wrong. Please try again.';
    emailError.hidden = false;
    return;
  }
  emailDialog.close();
  showSignedIn(result.instance);
});

async function init() {
  const state = await sendMessage({ type: 'getState' });
  if (state && state.signedIn) {
    showSignedIn(state.instance);
  } else {
    refreshChip();
  }
}

init();

// The popup is only open for seconds, but the socket can flip in that
// window (e.g. Chrome finishes waking up); a short poll keeps the chip
// honest without the boss having to reopen the popup to see it settle.
setInterval(refreshChip, 3000);
