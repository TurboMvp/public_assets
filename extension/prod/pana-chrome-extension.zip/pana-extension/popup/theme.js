// Classic script loaded in <head> so the theme is set before first paint;
// MV3 forbids inline scripts. The PACO theme keys dark mode off
// html[data-theme="dark"], not the media query, so mirror the OS setting.
(() => {
  const query = window.matchMedia('(prefers-color-scheme: dark)');
  const apply = () => document.documentElement.setAttribute('data-theme', query.matches ? 'dark' : 'light');
  apply();
  query.addEventListener('change', apply);
})();
